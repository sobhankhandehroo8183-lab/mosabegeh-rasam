import { useRef, useState } from 'react';

export default function VideoPlayer() {
  const videoRef = useRef(null);
  const [isMuted, setIsMuted] = useState(true);

  const toggleSound = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <div className="tv-wrapper">
      {/* آنتن‌های تلویزیون */}
      <div style={{ position: 'relative', height: '70px', display: 'flex', justifyContent: 'center' }}>
        {/* آنتن چپ */}
        <div style={{
          position: 'absolute',
          bottom: 0,
          left: '50%',
          marginLeft: '-45px',
          width: '10px',
          height: '65px',
          background: '#1a1a1a',
          borderRadius: '5px 5px 0 0',
          transform: 'rotate(-18deg)',
          transformOrigin: 'bottom center',
        }}>
          <div style={{
            position: 'absolute',
            top: '-8px',
            left: '50%',
            transform: 'translateX(-50%)',
            width: '18px',
            height: '18px',
            background: '#1a1a1a',
            borderRadius: '50%',
          }} />
        </div>
        {/* آنتن راست */}
        <div style={{
          position: 'absolute',
          bottom: 0,
          left: '50%',
          marginLeft: '35px',
          width: '10px',
          height: '65px',
          background: '#1a1a1a',
          borderRadius: '5px 5px 0 0',
          transform: 'rotate(18deg)',
          transformOrigin: 'bottom center',
        }}>
          <div style={{
            position: 'absolute',
            top: '-8px',
            left: '50%',
            transform: 'translateX(-50%)',
            width: '18px',
            height: '18px',
            background: '#1a1a1a',
            borderRadius: '50%',
          }} />
        </div>
      </div>

      {/* بدنه تلویزیون */}
      <div style={{
        background: 'linear-gradient(145deg, #2a2a2a, #111)',
        borderRadius: '28px',
        padding: '22px 22px 40px 22px',
        boxShadow: '0 0 0 5px #222, 0 0 0 9px #111, 0 15px 50px rgba(0,0,0,0.6)',
      }}>
        {/* صفحه تلویزیون */}
        <div className="tv-screen" style={{ borderRadius: '14px', overflow: 'hidden', position: 'relative', border: '4px solid #333', background: '#000' }}>
          <video
            ref={videoRef}
            className="video-element"
            src="/video.mp4"
            autoPlay
            loop
            muted={isMuted}
            playsInline
            style={{ width: '100%', display: 'block', aspectRatio: '4/3', objectFit: 'cover' }}
          />
          {/* دکمه ولوم */}
          <button
            className="volume-button"
            onClick={toggleSound}
            title="اگه صدا نداری اینجا کلیک کن"
          >
            {isMuted ? '🔇' : '🔊'}
          </button>
        </div>
        {/* نوار پایین تلویزیون */}
        <div style={{
          background: '#1a1a1a',
          color: '#aaa',
          padding: '8px 15px',
          textAlign: 'center',
          fontSize: '13px',
          marginTop: '0',
          borderRadius: '0 0 10px 10px',
        }}>
          💡 اگه صدا نداری روی دکمه نارنجی پایین ویدیو کلیک کن
        </div>
      </div>

      {/* پایه تلویزیون */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ width: '70px', height: '18px', background: '#1a1a1a', borderRadius: '0 0 8px 8px' }} />
        <div style={{ width: '130px', height: '10px', background: '#111', borderRadius: '5px', marginTop: '2px' }} />
      </div>
    </div>
  );
}

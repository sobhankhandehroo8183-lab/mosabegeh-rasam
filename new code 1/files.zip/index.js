import VideoPlayer from '../components/VideoPlayer';

export default function Home() {
  return (
    <div className="page-wrapper">
      <div className="container">
        <div className="hero-row">

          {/* ستون چپ: تلویزیون */}
          <VideoPlayer />

          {/* ستون راست: محتوا */}
          <div className="right-section">

            {/* بج مسابقه نقاشی */}
            <div className="contest-badge">
              <div className="contest-badge-text">مسابقه نقاشی کشوری</div>
              <div className="medal-icon">🥇</div>
            </div>

            {/* متن اگه صدا نداری */}
            <div className="sound-text">
              <p>اگه صدا نداری</p>
              <p>
                <span className="highlight">اینجا</span> کلیک کن
              </p>
            </div>

            {/* ریموت + متن */}
            <div className="remote-section">
              <div className="remote-text">
                <p>اگه ویدئو</p>
                <p>دیده نمیشه</p>
              </div>
              {/* ریموت کنترل */}
              <div
                className="remote"
                onClick={() => {
                  const vid = document.querySelector('video');
                  if (vid) vid.play();
                }}
                title="پخش ویدیو"
              >
                <div className="remote-arrow">▲</div>
                <div className="remote-arrow">▼</div>
                <div className="remote-play">▶</div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
